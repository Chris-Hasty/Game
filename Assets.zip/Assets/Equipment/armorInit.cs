using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class armorInit : MonoBehaviour
{
    public int defVal = 5;
    public int crafttime = 2;
    public int numInv = 5;
    public string weaponName = "Armor + 5";
}
