using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class weaponInit : MonoBehaviour
{
    public int attackVal = 5;
    public int crafttime = 2;
    public int numInv = 5;
    public string weaponName = "Sword + 5";
}
