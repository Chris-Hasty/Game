LeanTween is an efficient tweening engine for Unity3d

Full Documentation:
	http://dentedpixel.com/LeanTweenDocumentation/classes/LeanTween.html
	This can also be accessed offline! From the Unity menu Help->LeanTween Documentation

Getting Started
	
	There are many examples included! Look in the “LeanTween/LeanTweenExamples" folder to see many of the methods outlined. 
