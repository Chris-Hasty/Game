using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Building_data : MonoBehaviour
{
    public int[] pos = new int[] { 0, 0 };
    public int ID = 0;
}
