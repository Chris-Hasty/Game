using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mercCont : MonoBehaviour
{
    public List<GameObject> mercList;
    public List<GameObject> recruitList;
}
